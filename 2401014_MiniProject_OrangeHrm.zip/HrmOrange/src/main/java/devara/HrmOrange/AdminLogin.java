package devara.HrmOrange;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

//Linear code
public class AdminLogin {
	
	static WebDriver driver;
	static String baseUrl="https://opensource-demo.orangehrmlive.com";
	static List<WebElement> jobList;
	

	public void setUpDriver()
	{
		driver = new ChromeDriver();
		driver.get(baseUrl);
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	}
	
	
	public void login(String userName,String password)
	{
		driver.findElement(By.name("username")).sendKeys(userName);
		driver.findElement(By.name("password")).sendKeys(password);
		driver.findElement(By.xpath("//*[@id=\"app\"]/div[1]/div/div[1]/div/div[2]/div[2]/form/div[3]/button")).click();
		
	}
	

	public void getJobPage(String tobeAdded)
	{
		driver.findElement(By.xpath("//*[@id=\"app\"]/div[1]/div[1]/aside/nav/div[2]/ul/li[1]/a/span")).click();
		driver.findElement(By.xpath("//*[@id=\"app\"]/div[1]/div[1]/header/div[2]/nav/ul/li[2]/span")).click();
		driver.findElement(By.xpath("//*[@id=\"app\"]/div[1]/div[1]/header/div[2]/nav/ul/li[2]/ul/li[1]/a")).click();
		jobList=driver.findElements(By.xpath("/html/body/div/div[1]/div[2]/div[2]/div/div/div[3]/div/div"));
		System.out.println("The available job titles");
		for(WebElement str :jobList)
		{
			System.out.println(str.getText());
		}
		
		driver.findElement(By.xpath("/html/body/div/div[1]/div[2]/div[2]/div/div/div[1]/div/button")).click();
		
		
		
		driver.findElement(By.xpath("/html/body/div/div[1]/div[2]/div[2]/div/div/form/div[1]/div/div[2]/input")).sendKeys(tobeAdded);
		driver.findElement(By.xpath("/html/body/div/div[1]/div[2]/div[2]/div/div/form/div[5]/button[2]")).click();
		
		
		List<WebElement>jobNewList=driver.findElements(By.xpath("/html/body/div/div[1]/div[2]/div[2]/div/div/div[3]/div/div"));
		//System.out.println(jobNewList.size());
//		for(WebElement str :jobNewList)
//		{
//			System.out.println(str.getText());
//		}
		
		System.out.println();
		//System.out.println(jobNewList.get(0).getText());
		String jobs= jobNewList.get(1).getText();
//		if(jobs.contains("Automation Tester")) {
//			for(int i=0;i<arr.length;i++) {
//				
//			}
//		}
		String arr[]=jobs.split("\n");
		
		for(String str : arr)
		{
			if(str.equals(tobeAdded)) {
				System.out.println(tobeAdded+"==== added successfully====");
				break;
			}
		}
		System.out.println(arr.length +" ===job titles available after adding====");
		
		
		driver.findElement(By.xpath("/html/body/div/div[1]/div[1]/header/div[1]/div[3]/ul/li/span/i")).click();
		driver.findElement(By.xpath("/html/body/div/div[1]/div[1]/header/div[1]/div[3]/ul/li/ul/li[4]/a")).click();
	}
	
    
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		AdminLogin al = new AdminLogin();
		al.setUpDriver();
		al.login("Admin","admin123");
		al.getJobPage("Automation Tester");
	}

}
