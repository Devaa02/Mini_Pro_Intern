package tests;
import pages.*;

import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import java.io.IOException;
import base.BaseTest;

public class AdminLoginTest extends BaseTest {
	LoginPage loginPage;
	JobPage jobPage;
	
	@BeforeMethod
	public void setupPages()
	{
		loginPage = new LoginPage(driver);
	    jobPage= new JobPage(driver);
	}
   
    @Test(priority=0)
    public void testAdminLogin()
    {
        loginPage.login();
        Assert.assertTrue(loginPage.isLoggedIn(),"login Failed Invalid Credentials");
    	System.out.println("Login Successfull");
    }
    
    @Test(priority=1)
    public void navigate() throws IOException
    {
    	jobPage.navigateToJobPage();
        jobPage.writeTitlesToExcell();
    }

    @Test(priority=2,dataProvider="jobData",dataProviderClass= utils.ExcelData.class)
    public void deleteBeforeAdd(String...jobDetails)
    {
        jobPage.checkBeforeAdd(jobDetails[0]);
    }
   
   
    @Test(priority=3,dataProvider="jobData",dataProviderClass= utils.ExcelData.class)
    public void addJob(String jobTitle,String jobDescription,String jobNote) throws InterruptedException
    {
        jobPage.addJobTitle(jobTitle,jobDescription,jobNote); 
    }
    
  
    @Test(priority=4)
    public void logout() throws IOException
    {
        jobPage.logout();
    }
}

