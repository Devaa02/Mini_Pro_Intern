package utils;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.ss.usermodel.Row.MissingCellPolicy;
import org.apache.poi.xssf.usermodel.*;
import org.openqa.selenium.WebElement;
import org.testng.annotations.DataProvider;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;


public class ExcelData {
	
	@DataProvider(name="jobData")
	public static String[][] readExcellData() throws IOException
	{
		try {
		
		FileInputStream file = new FileInputStream(new File("src/Resources/AddData.xlsx"));
		Workbook workbook = new XSSFWorkbook(file);
		Sheet sheet = workbook.getSheetAt(0);
		int row_cnt = sheet.getPhysicalNumberOfRows();
		int cell_cnt= sheet.getRow(0).getPhysicalNumberOfCells();
		String[][] data=new String[row_cnt-1][cell_cnt];
	  
	    DataFormatter format = new DataFormatter();
	    for(int i=1;i<row_cnt;i++)
	    {
	    	Row row=sheet.getRow(i);
	    	for(int j=0;j<cell_cnt;j++)
	    	{
	    	Cell cell= row.getCell(j,MissingCellPolicy.CREATE_NULL_AS_BLANK);
	    	data[i-1][j]=format.formatCellValue(cell);
	    	}
	    }
	    
		workbook.close();
		return data;
		}catch(Exception e)
		{
			e.printStackTrace();
			return new String[0][0];
		}
	}
	
	public static void writeExcelData(List<WebElement> data)
	{
		Workbook book= new XSSFWorkbook();
		Sheet sheet = book.createSheet("Job_Titles");
		Row row = sheet.createRow(0);
		Cell cell=row.createCell(0);
		cell.setCellValue("JOB TITLES");
		int rowNum=1;
		for(WebElement ele : data)
		{
			row=sheet.createRow(rowNum++);
			cell=row.createCell(0);
			cell.setCellValue(ele.getText());
		}
		sheet.autoSizeColumn(0);
		String timestamp = new SimpleDateFormat("yyyy-MM-dd_HH-mm-ss").format(new Date());
		String fileName="C:\\Users\\2401014\\eclipse-workspace\\HrmOrange\\src\\test\\Resources\\Job_List_"+timestamp+".xlsx";
		
		FileOutputStream fout;
		try {
			fout = new FileOutputStream(fileName);
		
		book.write(fout);
		System.out.println("Data written into ExcellSheet");
		book.close();
	     }catch (FileNotFoundException e) {
				e.printStackTrace();
		} catch (IOException e) {
				e.printStackTrace();
		}
		
		
	}

}
