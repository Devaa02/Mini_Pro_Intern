package pages;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class LoginPage {
	
	WebDriver driver;
	
	@FindBy(xpath="//div[@class=\"orangehrm-login-error\"]/div/p")
	List<WebElement> credentials;

    @FindBy(name = "username")
    WebElement username;

    @FindBy(name = "password")
    WebElement password;

    @FindBy(xpath = "//button[@type=\"submit\"]")
    WebElement loginButton;
   
    @FindBy(xpath="//span[text()=\"Dashboard\"]")
    List<WebElement> loggedIn;  
    
    @FindBy(xpath="//p[text()=\"Invalid credentials\"]")
    List<WebElement> loginFail; 

    public LoginPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }
    
    public boolean isLoggedIn() 
    {
        if(!loggedIn.isEmpty() && loggedIn.get(0).isDisplayed())
    		return true;
		if(!loginFail.isEmpty() && loginFail.get(0).isDisplayed())
			return false;
		
	  return false;
    }

    public void login() 
    {
        username.sendKeys(credentials.get(0).getText().substring(11));
        password.sendKeys(credentials.get(1).getText().substring(11));
        loginButton.click();
    }

}
