package pages;
import utils.ExcelData;

import java.util.List;
import java.io.*;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;



public class JobPage {
	WebDriver driver;
	
    @FindBy(xpath = "//span[@class=\"oxd-text oxd-text--span oxd-main-menu-item--name\"  and text()=\"Admin\"]")
    WebElement Admin;

    @FindBy(xpath = "//span[@class=\"oxd-topbar-body-nav-tab-item\" and text()=\"Job \"]")
    WebElement job;

    @FindBy(linkText = "Job Titles")
    WebElement jobTitle;

    @FindBy(xpath = "//div[@class=\"oxd-table-body\"]/div/div/div[2]/div")
    List<WebElement> jobList;
  
    @FindBy(xpath="//button[@class=\"oxd-button oxd-button--medium oxd-button--label-danger orangehrm-horizontal-margin\"]")
    WebElement deletePrev;
    
    @FindBy(xpath="//div[@class=\"orangehrm-modal-footer\"]/button[2]")
    WebElement confirmDelPrev;

    @FindBy(xpath = "//button[@class=\"oxd-button oxd-button--medium oxd-button--secondary\"]")
    WebElement addButton;

    @FindBy(xpath = "(//input[@class=\"oxd-input oxd-input--active\"])[2]")
    WebElement jobTitleInput;
    
    @FindBy(xpath="//textarea[@placeholder=\"Type description here\"]")
    WebElement jobDescriptionInput;
    
    @FindBy(xpath="//textarea[@placeholder=\"Add note\"]")
    WebElement jobNoteInput;

    @FindBy(xpath = "//button[@type=\"submit\"]")
    WebElement saveButton;

    @FindBy(xpath = "//p[@class=\"oxd-userdropdown-name\"]")
    WebElement userDropdown;

    @FindBy(linkText = "Logout")
    WebElement logoutButton;

    public JobPage(WebDriver driver)
    {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }
    

    public void navigateToJobPage()
    {
        Admin.click();
        job.click();
        jobTitle.click();
    }
    
    public void checkBeforeAdd(String jobTitle)
    {
    	for(WebElement ele:jobList)
    	{
    		if(ele.getText().equalsIgnoreCase(jobTitle))
    		{
    			ele.findElement(By.xpath("./parent::div/preceding-sibling::div/div")).click();
    			((JavascriptExecutor) driver).executeScript("arguments[0].click();",deletePrev);
    	    	confirmDelPrev.click();
    	    	System.out.println("Previous record found,Deleted "+jobTitle);
    	    	break;
    		}
    	}
    }

    public void addJobTitle(String jobTitle,String jobDescription,String jobNote) throws InterruptedException
    {
    	((JavascriptExecutor) driver).executeScript("arguments[0].click();",addButton);
        jobTitleInput.sendKeys(jobTitle);
        jobDescriptionInput.sendKeys(jobDescription);
        jobNoteInput.sendKeys(jobNote);
        saveButton.click();
        System.out.println("Added "+jobTitle+" job");
		Thread.sleep(5000);
    }

    public void writeTitlesToExcell() throws IOException {
    	ExcelData.writeExcelData(jobList);
    }

    public void logout() {
        userDropdown.click();
        logoutButton.click();
        System.out.println("Logout Successfull");
    }
}
